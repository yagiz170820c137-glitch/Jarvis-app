JARVIS AI - Android APK projesi

Bu klasör bir Android uygulaması kaynak projesidir. İçinde:
- Gönderdiğiniz örneğe benzeyen JARVIS açılış ekranı
- Hologram arayüzü
- Dijital saat ve tarih
- Mikrofonla Türkçe konuşma tanıma
- Android'in Türkçe metin-okuma sesiyle cevap verme
- Basit örnek komut cevapları

ÖNEMLİ SINIRLAMA:
Bu ilk sürüm genel amaçlı çevrimiçi yapay zekâ değildir. "Merhaba", "saat kaç", "kimsin" gibi temel komutlara yanıt verir. Serbest sohbet için güvenli bir sunucu üzerinden bir yapay zekâ API bağlantısı eklenmelidir. API anahtarını doğrudan APK içine koymayın.

APK'yı buluttan üretme (bilgisayarda Android Studio gerekmez):
1. GitHub hesabıyla github.com adresine girin.
2. New repository seçerek boş bir depo oluşturun.
3. Bu ZIP'i açın ve içindeki TÜM dosya/klasörleri depoya yükleyin. .github klasörünü de yükleyin.
4. Depoda Actions sekmesine girin. "JARVIS APK build" iş akışını açın.
5. Run workflow düğmesine basın ve çalışmanın bitmesini bekleyin.
6. Tamamlanan çalışmanın sayfasındaki Artifacts bölümünden JARVIS-AI-APK dosyasını indirin.
7. ZIP'i telefonda açın; içindeki app-debug.apk dosyasına dokunarak kurun. Android kurulum sırasında izin isterse yalnızca bu kendi oluşturduğunuz dosya için izin verin.

İlk kurulum için mikrofon izni gereklidir. Ses tanıma Android cihazın konuşma hizmetine bağlıdır.
