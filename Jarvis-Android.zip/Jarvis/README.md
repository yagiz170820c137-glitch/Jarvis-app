# Jarvis (Android)

1. Android Studio'yu aç → Open → bu klasörü seç. Gradle senkronu bitsin (ilk seferde internet gerekir).
2. Menü: Build → Build Bundle(s) / APK(s) → Build APK(s).
3. APK: app/build/outputs/apk/debug/app-debug.apk. Telefona kopyala, kur ("bilinmeyen kaynak" iznini aç).
4. Uygulamayı aç, "Jarvis ile tanış"a bas, tüm izinleri ver.
   - "Diğer uygulamaların üzerinde göster": arka plandayken arama/uygulama açabilmesi için şart.
   - Pil: "Kısıtlama yok" seç. Xiaomi/Samsung/Oppo'da ayrıca Ayarlar > Uygulamalar > Jarvis > Pil > Kısıtlamasız yap.
5. Ekran kilitliyken ya da başka uygulamadayken "Jarvis, anneyi ara" de.

Komut örnekleri: anne ara | ali'ye mesaj at merhaba | ali'ye whatsapp yaz nasılsın |
instagram aç | sabah 7 30 alarm kur | 5 dakika sayaç kur | tarkan çal | haritada eczane | saat kaç
