package com.jarvis.app

import android.os.Handler
import android.os.Looper

/** Servis ile ekran arasındaki basit haberleşme. */
object JarvisBus {
    enum class State { IDLE, LISTEN, SPEAK }

    @Volatile var state = State.IDLE
    var onMessage: ((String, Boolean) -> Unit)? = null
    var onState: ((State) -> Unit)? = null
    val history = mutableListOf<Pair<String, Boolean>>()
    private val h = Handler(Looper.getMainLooper())

    fun post(text: String, user: Boolean) {
        history.add(text to user)
        if (history.size > 100) history.removeAt(0)
        h.post { onMessage?.invoke(text, user) }
    }

    fun setState(s: State) {
        state = s
        h.post { onState?.invoke(s) }
    }
}
