package com.jarvis.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

/** Arka planda "Jarvis" kelimesini dinleyen ön plan servisi. */
class JarvisService : Service(), RecognitionListener, TextToSpeech.OnInitListener {

    companion object {
        @Volatile var running = false
        const val CH = "jarvis"
        const val ACT_STOP = "jarvis.STOP"
        const val EXTRA_CMD = "cmd"

        fun start(ctx: Context, cmd: String? = null) {
            val i = Intent(ctx, JarvisService::class.java)
            if (cmd != null) i.putExtra(EXTRA_CMD, cmd)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, JarvisService::class.java)) }
    }

    private val main = Handler(Looper.getMainLooper())
    private val tr = Locale("tr", "TR")
    private val wake = Regex("[jcç]ar[vw][iıu]s")
    private var sr: SpeechRecognizer? = null
    private lateinit var tts: TextToSpeech
    private lateinit var cmd: CommandHandler
    private var ttsReady = false
    private var speaking = false
    private var pending = 0
    private var awakeUntil = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        tts = TextToSpeech(this, this)
        cmd = CommandHandler(this) { speak(it) }
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts.language = tr
        tts.setPitch(.85f)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { JarvisBus.setState(JarvisBus.State.SPEAK) }
            override fun onDone(id: String?) { finished() }
            @Deprecated("Deprecated in Java") override fun onError(id: String?) { finished() }
        })
        ttsReady = true
        speak("Jarvis çevrimiçi. Beni çağırmak için Jarvis de.")
    }

    private fun finished() = main.post {
        pending = (pending - 1).coerceAtLeast(0)
        if (pending == 0) {
            speaking = false
            main.postDelayed({ listen() }, 400)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACT_STOP) { stopSelf(); return START_NOT_STICKY }
        val n = notif()
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            JarvisBus.post("Bu telefonda ses tanıma servisi yok. Google uygulamasını kurup güncelle.", false)
        }
        intent?.getStringExtra(EXTRA_CMD)?.let { JarvisBus.post(it, true); cmd.handle(it) }
        if (!speaking) listen()
        return START_STICKY
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, JarvisService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Jarvis dinliyor")
            .setContentText("\"Jarvis\" diyerek çağır")
            .setContentIntent(open)
            .addAction(0, "Durdur", stop)
            .setOngoing(true)
            .build()
    }

    private fun listen() {
        if (!running || speaking) return
        try {
            if (sr == null) { sr = SpeechRecognizer.createSpeechRecognizer(this); sr!!.setRecognitionListener(this) }
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            sr!!.startListening(i)
            JarvisBus.setState(JarvisBus.State.LISTEN)
        } catch (e: Exception) {
            main.postDelayed({ listen() }, 2000)
        }
    }

    private fun speak(t: String) {
        JarvisBus.post(t, false)
        main.removeCallbacksAndMessages(null)
        speaking = true
        sr?.cancel()
        if (ttsReady) {
            pending++
            tts.speak(t, TextToSpeech.QUEUE_ADD, null, "j" + System.nanoTime())
        } else {
            speaking = false
            main.postDelayed({ listen() }, 500)
        }
    }

    private fun process(text: String) {
        val t = text.lowercase(tr).trim()
        val now = SystemClock.elapsedRealtime()
        val m = wake.find(t)
        val command: String
        if (m != null) {
            command = t.substring(m.range.last + 1).trim(' ', ',', '.', '!')
            awakeUntil = now + 8000
            if (command.isEmpty()) { speak("Efendim?"); return }
        } else if (now < awakeUntil) {
            command = t
        } else return
        awakeUntil = 0
        JarvisBus.post(command, true)
        cmd.handle(command)
    }

    override fun onResults(b: Bundle?) {
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
        if (!speaking) main.postDelayed({ listen() }, 250)
    }

    override fun onError(e: Int) {
        if (!running || speaking) return
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            JarvisBus.post("Mikrofon izni yok. Ayarlardan izin ver.", false)
            stopSelf(); return
        }
        if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) sr?.cancel()
        main.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 200 else 900)
    }

    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        sr?.destroy()
        if (ttsReady) { tts.stop(); tts.shutdown() }
        JarvisBus.setState(JarvisBus.State.IDLE)
        super.onDestroy()
    }
}
