package com.jarvis.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.text.HtmlCompat

class MainActivity : AppCompatActivity() {
    private lateinit var intro: View
    private lateinit var chat: View
    private lateinit var sphereA: SphereView
    private lateinit var sphereB: SphereView
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var input: EditText
    private var step = 0

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { advance() }
    private val settingsLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { advance() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        intro = findViewById(R.id.intro)
        chat = findViewById(R.id.chat)
        sphereA = findViewById(R.id.sphereA)
        sphereB = findViewById(R.id.sphereB)
        log = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)
        input = findViewById(R.id.input)

        findViewById<TextView>(R.id.introTitle).text =
            HtmlCompat.fromHtml("Merhaba. Ben <i><font color='#8D8DA0'>Jarvis.</font></i>", HtmlCompat.FROM_HTML_MODE_LEGACY)

        findViewById<Button>(R.id.go).setOnClickListener {
            step = 0
            val p = mutableListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
                Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS
            )
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            permLauncher.launch(p.toTypedArray())
        }
        findViewById<Button>(R.id.send).setOnClickListener { sendTyped() }
        input.setOnEditorActionListener { _, _, _ -> sendTyped(); true }
        toggle.setOnClickListener {
            if (JarvisService.running) JarvisService.stop(this) else if (hasMic()) JarvisService.start(this)
            updateUi()
        }
        if (hasMic()) showChat()
    }

    private fun advance() {
        step++
        when (step) {
            1 -> if (Settings.canDrawOverlays(this)) advance() else {
                Toast.makeText(this, "Jarvis için \"Diğer uygulamaların üzerinde göster\" iznini aç.", Toast.LENGTH_LONG).show()
                settingsLauncher.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            2 -> {
                val pm = getSystemService(PowerManager::class.java)
                if (pm.isIgnoringBatteryOptimizations(packageName)) advance()
                else settingsLauncher.launch(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            }
            else -> {
                if (!hasMic()) { Toast.makeText(this, "Mikrofon izni gerekli.", Toast.LENGTH_LONG).show(); return }
                showChat()
                JarvisService.start(this)
            }
        }
    }

    private fun showChat() {
        intro.visibility = View.GONE
        chat.visibility = View.VISIBLE
        updateUi()
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty() || !hasMic()) return
        input.setText("")
        JarvisService.start(this, t)
    }

    private fun updateUi() {
        toggle.text = if (JarvisService.running) "Durdur" else "Başlat"
        status.text = when {
            !JarvisService.running -> "Durduruldu"
            JarvisBus.state == JarvisBus.State.SPEAK -> "Konuşuyor…"
            else -> "Dinliyorum — \"Jarvis\" de"
        }
    }

    private fun bubble(t: String, user: Boolean) {
        val tv = TextView(this).apply {
            text = t
            textSize = 16f
            setTextColor(if (user) 0xFFD7DAF5.toInt() else 0xFFECEBE4.toInt())
            setPadding(dp(14), dp(10), dp(14), dp(10))
            setBackgroundResource(if (user) R.drawable.bubble_user else R.drawable.bubble_ai)
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            gravity = if (user) Gravity.END else Gravity.START
            topMargin = dp(8)
        }
        log.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onStart() {
        super.onStart()
        log.removeAllViews()
        JarvisBus.history.toList().forEach { bubble(it.first, it.second) }
        sphereA.mode = JarvisBus.state
        sphereB.mode = JarvisBus.state
        JarvisBus.onMessage = { t, u -> bubble(t, u) }
        JarvisBus.onState = { s -> sphereA.mode = s; sphereB.mode = s; updateUi() }
        updateUi()
    }

    override fun onStop() {
        JarvisBus.onMessage = null
        JarvisBus.onState = null
        super.onStop()
    }
}
