package com.jarvis.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.telephony.SmsManager
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Türkçe komutları çözer ve telefonda uygular. */
class CommandHandler(private val ctx: Context, private val say: (String) -> Unit) {
    private val tr = Locale("tr", "TR")
    private val h = Handler(Looper.getMainLooper())
    private val jokes = listOf(
        "Tony Stark kahveyi neden sever? Çünkü uyku, süper kahramanların kriptonitidir.",
        "Bir yapay zeka bara girmiş. Bartender: Ne içersin? Yapay zeka: Sadece birkaç bit.",
        "Beni neden Jarvis yaptılar? Çünkü Friday izinliydi."
    )

    private fun has(p: String) = ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    /** Konuşma bitsin diye biraz bekleyip uygulamayı açar. */
    private fun go(i: Intent, delay: Long = 1500) {
        h.postDelayed({
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e: Exception) {
                say("Bunu açamadım.")
            }
        }, delay)
    }

    private fun view(url: String) = go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))

    private fun findContact(q0: String): Pair<String, String>? {
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        val base = q0.substringBefore('\'').substringBefore('’').trim()
        val tries = listOf(base, base.dropLast(1), base.dropLast(2)).filter { it.length >= 2 }.distinct()
        val phone = ContactsContract.CommonDataKinds.Phone
        for (q in tries) {
            ctx.contentResolver.query(
                phone.CONTENT_URI,
                arrayOf(phone.DISPLAY_NAME, phone.NUMBER),
                "${phone.DISPLAY_NAME} LIKE ?", arrayOf("%$q%"), null
            )?.use { c -> if (c.moveToFirst()) return c.getString(0) to c.getString(1) }
        }
        return null
    }

    private fun call(name: String, num: String) {
        say("$name aranıyor.")
        val uri = Uri.parse("tel:" + Uri.encode(num))
        if (has(Manifest.permission.CALL_PHONE)) go(Intent(Intent.ACTION_CALL, uri)) else go(Intent(Intent.ACTION_DIAL, uri))
    }

    private fun waNumber(n: String): String {
        val d = n.filter { it.isDigit() }
        return if (d.startsWith("0")) "90" + d.drop(1) else d
    }

    @Suppress("DEPRECATION")
    private fun sendSms(num: String, msg: String) {
        val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
        sm.sendMultipartTextMessage(num, null, sm.divideMessage(msg), null, null)
    }

    private fun openApp(name: String): Boolean {
        val pm = ctx.packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        fun label(r: android.content.pm.ResolveInfo) = r.loadLabel(pm).toString().lowercase(tr)
        val hit = list.firstOrNull { label(it) == name } ?: list.firstOrNull { label(it).contains(name) } ?: return false
        val launch = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        say("${label(hit)} açılıyor.")
        go(launch, 900)
        return true
    }

    fun handle(raw: String) {
        val s = raw.lowercase(tr).trim().trimEnd('.', '!', '?')
        if (s.isEmpty()) return

        // Mesaj: "ali'ye mesaj at merhaba" / "ali'ye whatsapp yaz nasılsın"
        Regex("^(.+?)['’]?y?[ea]\\s+(mesaj|sms|whatsapp)\\s*(?:at|yaz|gönder|gonder)?\\s*(.*)$").find(s)?.let { m ->
            val (name, kind, msg) = m.destructured
            val c = findContact(name)
            if (c == null) { say("\"$name\" rehberde yok."); return }
            if (kind == "whatsapp") {
                say("${c.first} için WhatsApp açılıyor.")
                view("https://wa.me/${waNumber(c.second)}" + if (msg.isNotBlank()) "?text=" + Uri.encode(msg) else "")
            } else if (msg.isNotBlank() && has(Manifest.permission.SEND_SMS)) {
                try { sendSms(c.second, msg); say("${c.first} kişisine mesaj gönderildi.") } catch (e: Exception) { say("Mesaj gönderilemedi.") }
            } else {
                say("${c.first} için mesaj ekranı açılıyor.")
                go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${c.second}")).putExtra("sms_body", msg))
            }
            return
        }

        // Arama: "anne ara" / "05321234567 ara"
        Regex("^(.+?)\\s+(?:ara|arar mısın|arayabilir misin)$").find(s)?.let { m ->
            val who = m.groupValues[1]
            if (!Regex("google|youtube|internet").containsMatchIn(who)) {
                val d = who.replace(" ", "")
                if (Regex("^\\+?\\d{7,}$").matches(d)) { call(d, d); return }
                val c = findContact(who)
                if (c != null) call(c.first, c.second) else say("\"$who\" rehberde yok.")
                return
            }
        }

        // Sayaç: "5 dakika sayaç kur"
        Regex("(\\d+)\\s*(saniye|dakika|saat)").find(s)?.let { m ->
            if (Regex("sayaç|sayac|zamanlayıcı|hatırlat|uyar|sonra").containsMatchIn(s)) {
                val n = m.groupValues[1].toInt()
                val sec = n * when (m.groupValues[2]) { "saniye" -> 1; "dakika" -> 60; else -> 3600 }
                say("$n ${m.groupValues[2]} için sayaç kuruldu.")
                go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true), 800)
                return
            }
        }

        // Alarm: "sabah 7 30 alarm kur"
        if (s.contains("alarm")) {
            Regex("(\\d{1,2})(?:[:. ](\\d{2}))?").find(s)?.let { m ->
                var hh = m.groupValues[1].toInt()
                val mm = m.groupValues[2].ifEmpty { "0" }.toInt()
                if ((s.contains("akşam") || s.contains("öğleden sonra") || s.contains("gece")) && hh < 12) hh += 12
                if (hh in 0..23 && mm in 0..59) {
                    say("Alarm " + "%02d:%02d".format(hh, mm) + " için kuruldu.")
                    go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hh)
                        .putExtra(AlarmClock.EXTRA_MINUTES, mm).putExtra(AlarmClock.EXTRA_SKIP_UI, true), 800)
                    return
                }
            }
            say("Alarm saatini söyler misin? Örneğin: sabah 7 30 alarm kur.")
            return
        }

        if (Regex("saat kaç|saati söyle").containsMatchIn(s)) { say("Saat " + SimpleDateFormat("HH:mm", tr).format(Date()) + "."); return }
        if (Regex("bugün günlerden|hangi gün|tarih").containsMatchIn(s)) { say("Bugün " + SimpleDateFormat("d MMMM yyyy EEEE", tr).format(Date()) + "."); return }
        if (Regex("merhaba|selam|günaydın|iyi akşamlar").containsMatchIn(s)) { say("Merhaba. Size nasıl yardımcı olabilirim?"); return }
        if (Regex("kimsin|adın ne").containsMatchIn(s)) { say("Ben Jarvis, kişisel asistanınım."); return }
        if (s.contains("nasılsın")) { say("Tüm sistemler çalışıyor."); return }
        if (Regex("şaka|fıkra").containsMatchIn(s)) { say(jokes.random()); return }
        if (Regex("teşekkür|sağ ol").containsMatchIn(s)) { say("Rica ederim."); return }

        // Web araması
        Regex("^(.+?)\\s+(?:araştır|google'?da ara|internette ara)$").find(s)?.let { m ->
            say("${m.groupValues[1]} aranıyor.")
            view("https://www.google.com/search?q=" + Uri.encode(m.groupValues[1])); return
        }
        // Müzik / video
        Regex("^(.+?)\\s+(?:çal|dinlet|oynat)$").find(s)?.let { m ->
            say("${m.groupValues[1]} açılıyor.")
            view("https://www.youtube.com/results?search_query=" + Uri.encode(m.groupValues[1])); return
        }
        // Harita
        Regex("^haritada?\\s+(.+)$|^(.+?)\\s+yol tarifi$").find(s)?.let { m ->
            val q = m.groupValues[1].ifEmpty { m.groupValues[2] }.replace(Regex("\\s*(aç|göster)$"), "")
            say("Haritalar açılıyor.")
            view("geo:0,0?q=" + Uri.encode(q)); return
        }
        // Uygulama aç
        Regex("^(.+?)['’]?\\s*(?:y?[ıiuü])?\\s*(?:aç|başlat|çalıştır)$").find(s)?.let { m ->
            if (openApp(m.groupValues[1].trim())) return
            say("\"${m.groupValues[1]}\" uygulamasını bulamadım."); return
        }

        say("Bunu anlayamadım. Şunları dene: anne ara, ali'ye mesaj at merhaba, instagram aç, sabah 7 30 alarm kur, 5 dakika sayaç kur.")
    }
}
