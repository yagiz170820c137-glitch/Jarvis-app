package com.jarvis.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import com.jarvis.app.JarvisBus.State
import kotlin.math.*
import kotlin.random.Random

/** Dönen parçacık küresi. Dinlerken amber, konuşurken nabız gibi atar. */
class SphereView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var mode = State.IDLE
    private val n = 600
    private val pts = Array(n) { i ->
        val y = 1f - 2f * (i + .5f) / n
        val r = sqrt(1f - y * y)
        val th = i * 2.399963f
        floatArrayOf(cos(th) * r, y, sin(th) * r, Random.nextFloat() * 1.2f + .5f)
    }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var a = 0f

    override fun onDraw(c: Canvas) {
        a += when (mode) { State.LISTEN -> .012f; State.SPEAK -> .02f; else -> .004f }
        val k = when (mode) {
            State.SPEAK -> 1f + sin(System.currentTimeMillis() / 110.0).toFloat() * .04f
            State.LISTEN -> 1.03f
            else -> 1f
        }
        val cx = width / 2f
        val cy = height / 2f
        val rad = min(width, height) * .42f * k
        val s = sin(a)
        val co = cos(a)
        val dens = resources.displayMetrics.density
        for (p in pts) {
            val px = p[0] * co + p[2] * s
            val pz = -p[0] * s + p[2] * co
            val d = (pz + 1f) / 2f
            val alpha = ((.25f + .75f * d) * 255).toInt()
            paint.color = if (mode == State.LISTEN) Color.argb(alpha, 231, 179, 106) else Color.argb(alpha, 220, 222, 236)
            c.drawCircle(cx + px * rad, cy + p[1] * rad, p[3] * dens * (.6f + .5f * d), paint)
        }
        postInvalidateOnAnimation()
    }
}
